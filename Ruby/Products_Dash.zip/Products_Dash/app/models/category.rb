class Category < ApplicationRecord
	belongs_to :product
end
