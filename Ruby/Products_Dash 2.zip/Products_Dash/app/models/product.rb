class Product < ApplicationRecord
	has_many :categories
	has_many :comments

	validates :name, :description, :pricing, presence: true
	
end
